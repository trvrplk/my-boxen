# Riak Puppet Module for Boxen

## Usage

```puppet
include riak
```

## Required Puppet Modules

* `boxen`
* `homebrew`
* `stdlib`
